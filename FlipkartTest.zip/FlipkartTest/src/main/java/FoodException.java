public class FoodException extends Exception {
    public FoodException(String msg){
        super(msg);
    }
}
