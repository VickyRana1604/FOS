 enum SelectionStrategyType {
    LOWER_BILL_COST,
    HIGHER_RATING;
}
