enum OrderState {
    UNACCEPTED,
    ACCEPTED,
    CANCELLED,
    COMPLETED;
}
