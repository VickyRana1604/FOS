import java.util.List;

public interface RestraurantSelectionStrategy {
    Restraurant selectRestraurant(List<FoodItem> orderedItems,List<Restraurant> restraurantList) throws OrderException;
}
