import lombok.Builder;

@Builder
public class MenuItem{
    String name;
    double price;
}
