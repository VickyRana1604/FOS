import java.util.ArrayList;
import java.util.List;

import java.util.HashMap;

public class FoodOrderService {

    HashMap<String,Restraurant> allRestraurants=new HashMap<>();
    List<Restraurant> restraurants=new ArrayList<>();

    public String onboardRestraurant(Restraurant restraurant) throws FoodException {
        if(allRestraurants.get(restraurant.name)!=null){
            throw new FoodException("Restro duplicate");
        }
        allRestraurants.putIfAbsent(restraurant.name,restraurant);
        restraurants.add(restraurant);
        return "restraurant added successfully";
    }
    public String updateRestraurant(String restroName,MenuItem item) throws FoodException {
        allRestraurants.get(restroName).addMenuItem(item);
        return "restro is updated successfully";
    }
    public Restraurant orderFood(Order order) throws OrderException {
        return order.selectionStrategy.selectRestraurant(order.foodItemList,restraurants);
    }


}
