import lombok.Builder;

@Builder
public class User {
    String name;
}
