public class FoodItem {
    String name;
    int q;
    public FoodItem(String name,int q){
        this.name=name;
        this.q=q;

    }
}
