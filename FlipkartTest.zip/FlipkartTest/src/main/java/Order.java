import lombok.Builder;

import java.util.List;

@Builder
public class Order {
    String id;
    User user;
    List<FoodItem> foodItemList;
    RestraurantSelectionStrategy selectionStrategy;
    OrderState state;
}
